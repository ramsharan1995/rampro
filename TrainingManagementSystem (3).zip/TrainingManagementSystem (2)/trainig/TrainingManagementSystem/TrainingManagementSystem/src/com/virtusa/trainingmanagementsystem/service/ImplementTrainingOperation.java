package com.virtusa.trainingmanagementsystem.service;


import java.util.Scanner;
import java.util.Map.Entry;

import com.virtusa.trainingmanagementsystem.dao.FeedbackDao;
import com.virtusa.trainingmanagementsystem.dao.RequestNominationDao;
import com.virtusa.trainingmanagementsystem.dao.TechnologyListDao;
import com.virtusa.trainingmanagementsystem.model.RequestNomination;
import com.virtusa.trainingmanagementsystem.validation.DataValidation;

public class ImplementTrainingOperation  implements TraineeOperation,Feedback{

	
	private Scanner sc;


	public void cancelNomination(String userName) {
		
	int i=0;
		for (Entry<String, RequestNomination> data : RequestNominationDao.reqNomination.entrySet()) {
		    if(data.getKey().equals(userName) )
		    {
		    	i=1;
		    }
		}
		if(i==1)
		{
			RequestNominationDao.reqNomination.remove(userName);
			System.out.println("your nomination has canceled");
			
		}
		else
		{
			System.out.println("Please enroll or nominate first");
		}
		
		
	}

	
	public void attendingHistory() {
		System.out.println(" nomination history");
		
		
	}


	@Override
	public void nomination(String userName) {
	DataValidation datavalidation=new DataValidation();
		System.out.println("chose Technology");
		new TechnologyListDao();
		for(String s:TechnologyListDao.techList)
			System.out.println(s);
		sc = new Scanner(System.in);
		RequestNomination nomination=new RequestNomination();
		
		System.out.println("Enter Technology");
		String technology=sc.nextLine();
       while(!(datavalidation.validateTechnology(technology))) {
			System.out.println("please enter correct Technology Start with Capital letter");
    		technology=sc.nextLine();
		}
		nomination.setTechnology(technology);
	   
		System.out.println("Enter Employee Name");
	    String emp_name=sc.nextLine();
	    while(!(datavalidation.validateName(emp_name))) {
			System.out.println("please enter correct employee name Start with Capital letter ");
			emp_name=sc.nextLine();
		}
		nomination.setEmp_name(emp_name);
		
		System.out.println("Enter Employee Email");
		String emp_mail=sc.nextLine();
		while(!(datavalidation.validateMail(emp_mail))) {
			System.out.println("please enter correct employee mail address end with @virtusa.com ");
			emp_mail=sc.nextLine();
		}
		nomination.setEmp_email(emp_mail);
		
		System.out.println("Enter Employee id");
		int emp_id=sc.nextInt();
		while(!(datavalidation.validateEmployeeId(emp_id))) {
			System.out.println("please enter correct employee id ");
			emp_id=sc.nextInt();
		}
		nomination.setEmp_id(emp_id);
		
		
		new RequestNominationDao().request(userName,nomination);
		System.out.println("your request sended");
		
	}


	@Override
	public void giveFeedback() {
		// TODO Auto-generated method stub
		
		System.out.println("give feedback......");
		new FeedbackDao();
		sc = new Scanner(System.in);
		String feedback1=sc.nextLine();
	  FeedbackDao.feedback.add(feedback1);
		System.out.println("Thanks for giving feedback");
	}


	@Override
	public void viewFeedback() {
		// TODO Auto-generated method stub
		for(String s1:FeedbackDao.feedback) {
			System.out.println(s1);
		}
	}}


	




