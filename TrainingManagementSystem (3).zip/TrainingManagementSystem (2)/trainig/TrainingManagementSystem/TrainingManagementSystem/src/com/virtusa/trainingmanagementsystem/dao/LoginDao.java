package com.virtusa.trainingmanagementsystem.dao;
import java.util.LinkedHashMap;

import com.virtusa.trainingmanagementsystem.model.Login;


	
	public class LoginDao {
	 public static LinkedHashMap<String, Login> logData=new LinkedHashMap<String, Login>();

	public LoginDao() {
		Login data1=new Login();
		data1.setUserName("Ram");

		data1.setPassword("Ram@123");
		data1.setDesignation("Trainee");
		logData.put("Ram", data1);
		
		Login data2=new Login();
		data2.setUserName("Ramanakar");
		data2.setPassword("Ramanakar@123");
		data2.setDesignation("Trainee");
		logData.put("Ramanakar", data2);
		
		Login data3=new Login();
		data3.setUserName("Anitha");
		data3.setPassword("Anitha@123");
		data3.setDesignation("Manager");
		logData.put("Anitha", data3);
		
		Login data4=new Login();
		data4.setUserName("Priya");
		data4.setPassword("Priya@123");
		data4.setDesignation("Admin");
		logData.put("Priya", data4);

	}
	}

