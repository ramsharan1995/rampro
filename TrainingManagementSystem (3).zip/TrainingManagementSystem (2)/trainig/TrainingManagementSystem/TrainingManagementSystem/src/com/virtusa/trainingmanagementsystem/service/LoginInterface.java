package com.virtusa.trainingmanagementsystem.service;

public interface LoginInterface {
void loginCheck();
}
