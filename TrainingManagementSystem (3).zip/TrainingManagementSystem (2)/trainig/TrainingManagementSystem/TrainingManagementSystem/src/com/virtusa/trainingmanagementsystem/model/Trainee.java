package com.virtusa.trainingmanagementsystem.model;

public class Trainee {
int traineeId;
String traineeName;
String traineeMail;
long mobileNo;
String technologies;
public int getTraineeId() {
	return traineeId;
}
public void setTraineeId(int traineeId) {
	this.traineeId = traineeId;
}
public String getTraineeName() {
	return traineeName;
}
public void setTraineeName(String traineeName) {
	this.traineeName = traineeName;
}
public String getTraineeMail() {
	return traineeMail;
}
public void setTraineeMail(String traineeMail) {
	this.traineeMail = traineeMail;
}
public long getMobileNo() {
	return mobileNo;
}
public void setMobileNo(long mobileNo) {
	this.mobileNo = mobileNo;
}
public String getTechnologies() {
	return technologies;
}
public void setTechnologies(String technologies) {
	this.technologies = technologies;
}


}


