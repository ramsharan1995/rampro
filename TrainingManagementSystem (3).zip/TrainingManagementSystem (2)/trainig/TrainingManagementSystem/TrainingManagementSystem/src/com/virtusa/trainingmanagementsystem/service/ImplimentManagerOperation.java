package com.virtusa.trainingmanagementsystem.service;
import java.util.Map.Entry;
import java.util.Scanner;

import com.virtusa.trainingmanagementsystem.dao.RequestNominationDao;
import com.virtusa.trainingmanagementsystem.model.RequestNomination;
public class ImplimentManagerOperation implements ManagerOperation {

	@Override
	public void approveOrCancelRequest() {
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.println("---------------------Request Sended by nominee-----------------------");
		new RequestNominationDao();
		for (Entry<String, RequestNomination> data : RequestNominationDao.reqNomination.entrySet()) {
		    
		    	System.out.println(data.getValue().getEmp_name()+"  "+data.getValue().getEmp_id()+" "+data.getValue().getEmp_email()+" "+data.getValue().getTechnology());
		    	
		    }

		for(Entry<String, RequestNomination> data1 : RequestNominationDao.reqNomination.entrySet()){
			System.out.println("Request is \n");
			System.out.println(data1.getValue().getEmp_name()+"  "+data1.getValue().getEmp_id()+" "+data1.getValue().getEmp_email()+" "+data1.getValue().getTechnology());
			System.out.println("if you want to accepet press y  or reject press n");
			String a=sc.nextLine();
	    	if(a.equals("y")) {
	    		System.out.println("  namination is accepted");
	    	}
	    	else
	    		System.out.println(" namination is rejected");
		}
		
	}

	
	

}
