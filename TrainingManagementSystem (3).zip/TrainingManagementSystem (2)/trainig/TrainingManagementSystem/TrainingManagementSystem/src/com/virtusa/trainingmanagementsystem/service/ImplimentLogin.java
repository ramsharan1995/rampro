
package com.virtusa.trainingmanagementsystem.service;
import java.util.Scanner;

import com.virtusa.trainingmanagementsystem.dao.LoginDao;
import com.virtusa.trainingmanagementsystem.model.Login;
import com.virtusa.trainingmanagementsystem.validation.*;
public class ImplimentLogin implements LoginInterface {
	
 
	@Override
	public void loginCheck() {
		// TODO Auto-generated method stub
		LoginDao existData=new LoginDao();
		DataValidation datavalidation=new DataValidation();
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter username");
		String userName=sc.nextLine();
		 while(!(datavalidation.validateName(userName))) 
	    	 {
	    		System.out.println("please enter correct user name Start with Capital letter");
	    		userName=sc.nextLine();
	    		
	    	 }
	    	  
	    	
		System.out.println("Enter password");
		String password=sc.nextLine();
		while(!(datavalidation.validatePassword(password))) {
			System.out.println("please enter correct password");
    		password=sc.nextLine();
		}
		System.out.println("Enter designation");
		String designation=sc.nextLine();
		while(!(datavalidation.validateName(designation))) {
			System.out.println("please enter correct designation Start with Capital letter");
    		designation=sc.nextLine();
		}
		Login enterData=new Login();
		enterData.setUserName(userName);;
		enterData.setPassword(password);
		enterData.setDesignation(designation);
		new LoginVerification().verification(enterData,existData);
    
      }
		
		
	
	
	}

