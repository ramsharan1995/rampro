package com.virtusa.trainingmanagementsystem.dao;

import java.util.LinkedHashMap;

import com.virtusa.trainingmanagementsystem.model.RequestNomination;

public class RequestNominationDao {
	 public static LinkedHashMap<String, RequestNomination> reqNomination=new LinkedHashMap<String, RequestNomination>();
		
	 public void request(String userName,RequestNomination e)
	{
		reqNomination.put(userName,e);
	}
}
