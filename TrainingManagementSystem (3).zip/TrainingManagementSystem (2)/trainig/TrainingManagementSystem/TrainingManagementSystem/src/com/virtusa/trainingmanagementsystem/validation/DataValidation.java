package com.virtusa.trainingmanagementsystem.validation;

public class DataValidation {

	 public boolean validatePassword(String password){
if(password.matches(".*[a-z][A-Z]*..*[0-9]{1,}.*") && password.matches(".*[@#$]{1,}.*")
		&& password.length()>=6 && password.length()<=20)
		                    {
		                                    return true;
		                    }
		                    else
		                    {
		                                    return false;
		                    }
		       }
	 public  boolean validateName(String username) {
		 if (username.matches("[A-Z][a-z]+"))
		    {
		return true;
		}
		else
		{
		return false;
		}
	 }
	 public boolean validateMail(String mail) {
		  if(mail.matches("^[a-z]+@virtusa.com")) {
			  return true;
		 }
		  else
			{
			return false;
			}
         
		}
	 public  boolean validateTechnology(String technology) {
		 if (technology.matches("[A-Z][a-z]+") || technology.matches(".*[+#].*"))
		    {
		return true;
		}
		else
		{
		return false;
		}
		 }
		 public  boolean validateEmployeeId(int emp_id) {
			 if (emp_id % 10>=0)
			    {
			return true;
			}
			else
			{
			return false;
			}
}
}

