package com.virtusa.trainingmanagementsystem.main;
import com.virtusa.trainingmanagementsystem.service.ImplimentLogin;
public class LoginMain {
	public static void main(String args[]) {
		ImplimentLogin implimentlogin=new ImplimentLogin();
		int i=0;
		while(i<10) {
	
		implimentlogin.loginCheck();
		i++;
		}

	}
}
