package com.virtusa.trainingmanagementsystem.service;

//public class ImplementTrainer implements FeedbackDao,ScheduleTraining
//{
//
//	
//	
//	
//
//}
