package com.virtusa.trainingmanagementsystem.service;

public interface ManagerOperation {
	void approveOrCancelRequest();
	//void userAttendanceRepot();

}
