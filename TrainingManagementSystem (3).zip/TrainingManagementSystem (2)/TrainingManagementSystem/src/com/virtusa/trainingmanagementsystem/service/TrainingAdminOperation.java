package com.virtusa.trainingmanagementsystem.service;

import java.util.Scanner;

import com.virtusa.trainingmanagementsystem.dao.AcceptedNaminationDao;
import com.virtusa.trainingmanagementsystem.dao.ScheduleTrainingDao;
import com.virtusa.trainingmanagementsystem.dao.TechnologyListDao;
import com.virtusa.trainingmanagementsystem.model.RequestNomination;
import com.virtusa.trainingmanagementsystem.model.ScheduleTraining;

public class TrainingAdminOperation  {
	void listOfTrainees()
	{
		System.out.println("**************Approved Trainee List***************");
		for(RequestNomination data:AcceptedNaminationDao.acceptnaminationdao)
		{
			System.out.println(data.getEmp_name()+"  "+data.getEmp_id()+" "+data.getEmp_email()+" "+data.getTechnology());
			
		}
		
	}
	

	 void  scheduleTraining()
	 {
		 System.out.println("Technology List for which venue has to be added");
		 for(String s:TechnologyListDao.techList)
		 {String slot;
		 String location;
		 String date;
			 @SuppressWarnings("resource")
			Scanner sc=new Scanner(System.in);
			 System.out.print("add Date for"+s+":");
			 date=sc.nextLine();
			 System.out.print("add location for"+s+":");
			 location=sc.nextLine();
			 System.out.print("add slot for"+s+":");
			 slot=sc.nextLine();
			 ScheduleTraining venue1=new ScheduleTraining();
			 venue1.setDate(date);
			 venue1.setLocation(location);
			 venue1.setSlot(slot);
			 venue1.setTechnology(s);
			 new ScheduleTrainingDao().addVenue(venue1);
			 
		 }
		 
	 }
	 
}
