package com.virtusa.trainingmanagementsystem.service;

public interface TrainingStatus 
{

	void trainingDetail();
	void trainerDetails();

}
