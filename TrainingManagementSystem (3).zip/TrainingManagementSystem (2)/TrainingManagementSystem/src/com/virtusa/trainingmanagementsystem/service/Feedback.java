package com.virtusa.trainingmanagementsystem.service;

public interface Feedback {

	void  giveFeedback();
	void viewFeedback();
}
