package com.virtusa.trainingmanagementsystem.dao;

import java.util.Vector;

import com.virtusa.trainingmanagementsystem.model.Trainer;

public class TrainerDao {
	static Vector<Trainer> trainerData=new Vector<>();
	TrainerDao()
	{
		Trainer e=new Trainer();
		e.setTrainerId(123);
		e.setTrainerName("raja hindustani");
	}

}
