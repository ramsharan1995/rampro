package com.virtusa.trainingmanagementsystem.dao;

import java.util.Vector;

import com.virtusa.trainingmanagementsystem.model.ScheduleTraining;

public class ScheduleTrainingDao {
 
	public static Vector<ScheduleTraining> venue=new Vector<>();
public void addVenue(ScheduleTraining e)
	{
		venue.add(e);
	}
	
}
