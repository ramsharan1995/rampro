package com.virtusa.trainingmanagementsystem.dao;

import java.util.LinkedHashMap;

import com.virtusa.trainingmanagementsystem.model.Login;

public class LoginDao {
	public static LinkedHashMap<String, Login> logData=new LinkedHashMap<String, Login>();
    
	public LoginDao() {
		Login data1=new Login();
		data1.setUsername("ram");
		data1.setPassword("Ram@123");
		data1.setDesignation("Trainee");
		logData.put("ram", data1);
		Login data2=new Login();
		data2.setUsername("ramanakar");
		data2.setPassword("Ramanakar@123");
		data2.setDesignation("Trainee");
		logData.put("ramanakar", data2);
		Login data3=new Login();
		data3.setUsername("anitha");
		data3.setPassword("Anitha@123");
		data3.setDesignation("Manager");
		logData.put("anitha", data3);
		Login data4=new Login();
		data4.setUsername("priya");
		data4.setPassword("priya@123");
		data4.setDesignation("Admin");
		logData.put("priya", data4);



}}
