package com.virtusa.trainingmanagementsystem.model;

public class ScheduleTraining {
	String location;
	String technology;
	String date;
	String slot;

	public String getLocation() {
		return location;
	}
	public void setLocation( String location) {
		this.location = location;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date; 
	}
	public String getSlot() {
		return slot;
	}
	public void setSlot(String slot) {
		this.slot = slot;
	}

}
